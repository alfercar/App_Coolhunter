define({
  "_themeLabel": "موضوع لوحة التشغيل",
  "_layout_default": "تخطيط افتراضي",
  "_layout_right": "تخطيط صحيح"
});