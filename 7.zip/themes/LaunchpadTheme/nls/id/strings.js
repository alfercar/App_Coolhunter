define({
  "_themeLabel": "Tema Launchpad",
  "_layout_default": "Tata letak default",
  "_layout_right": "Tata letak kanan"
});