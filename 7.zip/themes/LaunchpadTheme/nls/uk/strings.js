define({
  "_themeLabel": "Тема Launchpad",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_right": "Компонування справа"
});